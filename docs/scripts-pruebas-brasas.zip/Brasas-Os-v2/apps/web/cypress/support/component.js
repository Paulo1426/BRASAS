import { mount } from "cypress/react";
import "../../src/index.css"; // estilos Tailwind reales del proyecto

Cypress.Commands.add("mount", mount);
